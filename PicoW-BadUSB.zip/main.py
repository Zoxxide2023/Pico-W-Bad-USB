from src.command import Command

if __name__ == "__main__":
    Command().execute("./payload.txt")