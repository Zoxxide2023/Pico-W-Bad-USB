from src.boot import Boot

# Loads default device setup
if __name__ == "__main__":
    Boot()
